# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from enigma import addFont
from Screens.MessageBox import MessageBox
from Components.config import config
from Plugins.Extensions.IPaudioPro.IPAudioProBase import IPAudioProHandler
from Plugins.Extensions.IPaudioPro.IPAudioProMain import IPAudioProMain, IPAudioProLauncher
from Plugins.Extensions.IPaudioPro.commons import isHD, confIPAudioPro
from Plugins.Extensions.IPaudioPro.IPAudioProWebInterface import getRoot
from Plugins.Extensions.IPaudioPro.__init__ import __version__
import os

addFont("/usr/lib/enigma2/python/Plugins/Extensions/IPaudioPro/assets/fonts/IPPro.ttf", "IPPro-icons", 100, 1)
addFont("/usr/lib/enigma2/python/Plugins/Extensions/IPaudioPro/assets/fonts/font_default.otf", "ArabicFont", 100, 1)


def addWebInterface():
    if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/__init__.pyc") or os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/__init__.pyo") or os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/__init__.py"):
        from Plugins.Extensions.WebInterface.WebChilds.Toplevel import addExternalChild
        try:
            addExternalChild(("ipaudiopro", getRoot(), "IPAudioPro", __version__))
            print("use new OpenWebIF")
        except:
            pass

def sessionstart(reason, session=None, **kwargs):
    if reason == 0 and not isHD():
        addWebInterface()
        IPAudioProHandler(session)
        IPAudioProLauncher(session).gotSession()
        try:
            config.timeshift.skipreturntolive.value = True
            config.timeshift.skipreturntolive.save()
        except:
            pass
        try:
            config.usage.timeshift_skipreturntolive.value = True
            config.usage.timeshift_skipreturntolive.save()
        except:
            pass


def autostart(reason, **kwargs):
    if reason == 1 and IPAudioProHandler.ipaudioPlayer:
        IPAudioProHandler.ipaudioPlayer = None

def main(session, **kwargs):
    if isHD():
        session.open(MessageBox, _('Skin is not supported\IPAudioPro works only with FHD skins'), MessageBox.TYPE_ERROR)
    else:
        session.open(IPAudioProMain)


def showInmenu(menuid, **kwargs):
    if menuid == "mainmenu":
        return [("IPAudioPro", main, "Listen to your favorite commentators", 1)]
    else:
        return []


def Plugins(**kwargs):
    Descriptors = []
    Descriptors.append(PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart))
    Descriptors.append(PluginDescriptor(where=[PluginDescriptor.WHERE_AUTOSTART], needsRestart=True, fnc=autostart))
    if confIPAudioPro.mainmenu.value:
        Descriptors.append(PluginDescriptor(where=[PluginDescriptor.WHERE_MENU], fnc=showInmenu))
    Descriptors.append(PluginDescriptor(name="IPAudioPro", description="Listen to your favorite commentators", icon="logo.png", where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main))
    return Descriptors
